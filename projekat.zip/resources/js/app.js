import "./bootstrap";

console.log("linked");
