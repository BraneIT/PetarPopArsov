

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .erasmus-wrapper{
            width: 100%;
            height: 100dvh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .under-construction{
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .under-construction > h1{
            text-align: center
        }
    </style>
</head>
<body>
    <div class="erasmus-wrapper">
        <div class="under-construction">
        <img src="{{asset('assets/images/logo-manji150.webp')}}" alt="">
        <h1>Бараната страница не е пронајдена. </br>Ве молиме вратете се назад </h1>
        
        </div>
    </div>
    
</body>
</html>



