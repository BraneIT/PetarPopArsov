@extends('frontend_views.layout.layout')

@section('title', '')

@section('content')


<div class="erasmus-wrapper">
    <div class="under-construction">
    <img src="{{asset('assets/images/logo-manji150.webp')}}" alt="">
    <h1>Почитувани, страницата е во изработка. Бараните содржини може да ги погледнете наскоро</h1>
    </div>
</div>

@endsection