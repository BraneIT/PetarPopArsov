@extends('frontend_views.layout.layout')

@section('title', 'Планирања за оценување')

@section('content')
<div class="pages-intro">
    <div class="pages-intro-container">
        <h1>Планирања за оценување</h1>
    </div>
</div>  
<div class="erasmus-wrapper">

    <div class="documents-container">
        <div class="grades-wrapper">
        <img src="{{ asset('assets/images/planiranja za ocenuvanje.PNG') }}" alt=""></div>
    </div>
</div>



@endsection